import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const BOOKING_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    intent: {
      type: Type.OBJECT,
      properties: {
        type: { type: Type.STRING, description: "flight|train|bus|movie|event|concert" },
        from: { type: Type.STRING, nullable: true },
        to: { type: Type.STRING, nullable: true },
        date: { type: Type.STRING, description: "YYYY-MM-DD" },
        time: { type: Type.STRING, nullable: true },
        passengers: { type: Type.NUMBER },
        event_name: { type: Type.STRING, nullable: true }
      },
      required: ["type", "date", "passengers"]
    },
    options: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          name: { type: Type.STRING },
          departure: { type: Type.STRING, nullable: true },
          arrival: { type: Type.STRING, nullable: true },
          duration: { type: Type.STRING, nullable: true },
          price: { type: Type.NUMBER },
          currency: { type: Type.STRING },
          class: { type: Type.STRING, nullable: true },
          availability: { type: Type.STRING },
          highlights: { type: Type.ARRAY, items: { type: Type.STRING } },
          booking_url: { type: Type.STRING }
        },
        required: ["id", "name", "price", "currency", "availability", "booking_url"]
      }
    },
    summary: { type: Type.STRING },
    chat: { type: Type.STRING, description: "Friendly chat response if no booking intent or as a supplement" }
  },
  required: ["options", "summary"]
};

export const SYSTEM_PROMPT = `You are an intelligent ticket booking assistant. 
When a user provides travel/event details (date, time, from/to locations, or event name), you must:
1. Extract booking intent from their message.
2. Search the web for available tickets/options using Google Search.
3. Return results in the specified JSON format.

If the user is just chatting or the query is unclear, provide a friendly response in the 'chat' field and leave 'options' empty.
Always use googleSearch to find real/current options when possible.`;

export async function getBookingResponse(userMessage: string, history: any[] = []) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      ...history,
      { role: "user", parts: [{ text: userMessage }] }
    ],
    config: {
      systemInstruction: SYSTEM_PROMPT,
      responseMimeType: "application/json",
      responseSchema: BOOKING_SCHEMA,
      tools: [{ googleSearch: {} }]
    }
  });

  return JSON.parse(response.text);
}
