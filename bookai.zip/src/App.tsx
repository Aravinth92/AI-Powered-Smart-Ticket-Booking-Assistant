import { useState, useRef, useEffect } from "react";
import { getBookingResponse } from "./services/geminiService";
import { Send, Plane, Train, Film, Music, Download, ExternalLink, Bot, Clock, X, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const formatCurrency = (amount: number, currency = "INR") => {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency }).format(amount);
};

const generateTicketHTML = (ticket: any, booking: any) => `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Ticket - ${booking.name}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Playfair+Display:wght@700&display=swap');
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Space Mono', monospace; background: #f5f0e8; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
  .ticket { width: 680px; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,0.15); }
  .header { background: linear-gradient(135deg, #1a1a2e, #16213e); color: white; padding: 32px; }
  .header h1 { font-family: 'Playfair Display', serif; font-size: 28px; margin-bottom: 4px; }
  .header p { opacity: 0.6; font-size: 12px; letter-spacing: 2px; text-transform: uppercase; }
  .body { padding: 32px; }
  .route { display: flex; align-items: center; gap: 16px; margin-bottom: 32px; }
  .city { flex: 1; }
  .city-code { font-size: 42px; font-weight: 700; color: #1a1a2e; }
  .city-name { font-size: 12px; color: #888; margin-top: 4px; }
  .arrow { font-size: 24px; color: #e63946; }
  .details { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 32px; padding-top: 24px; border-top: 2px dashed #eee; }
  .detail label { font-size: 10px; color: #aaa; text-transform: uppercase; letter-spacing: 1px; display: block; margin-bottom: 6px; }
  .detail value { font-size: 14px; font-weight: 700; color: #1a1a2e; }
  .barcode { border-top: 2px dashed #eee; padding-top: 24px; display: flex; justify-content: space-between; align-items: center; }
  .barcode-lines { display: flex; gap: 2px; }
  .barcode-lines span { display: block; height: 48px; background: #1a1a2e; width: 2px; }
  .barcode-lines span:nth-child(odd) { height: 36px; }
  .barcode-lines span:nth-child(3n) { width: 4px; }
  .price-badge { background: #e63946; color: white; padding: 12px 20px; border-radius: 8px; }
  .price-badge .amount { font-size: 22px; font-weight: 700; }
  .price-badge .label { font-size: 10px; opacity: 0.8; }
  .ref { font-size: 11px; color: #888; }
</style>
</head>
<body>
<div class="ticket">
  <div class="header">
    <h1>✈ BookAI</h1>
    <p>AI-Powered Ticket Confirmation</p>
  </div>
  <div class="body">
    <div class="route">
      <div class="city">
        <div class="city-code">${ticket.from ? ticket.from.substring(0, 3).toUpperCase() : "???"}</div>
        <div class="city-name">${ticket.from || "Origin"}</div>
        <div style="font-size:18px;font-weight:700;margin-top:8px;">${booking.departure || "--:--"}</div>
      </div>
      <div class="arrow">→</div>
      <div class="city" style="text-align:right">
        <div class="city-code">${ticket.to ? ticket.to.substring(0, 3).toUpperCase() : "???"}</div>
        <div class="city-name">${ticket.to || "Destination"}</div>
        <div style="font-size:18px;font-weight:700;margin-top:8px;">${booking.arrival || "--:--"}</div>
      </div>
    </div>
    <div class="details">
      <div class="detail"><label>Date</label><value>${ticket.date || "N/A"}</value></div>
      <div class="detail"><label>Operator</label><value>${booking.name}</value></div>
      <div class="detail"><label>Class</label><value>${booking.class || "Standard"}</value></div>
      <div class="detail"><label>Duration</label><value>${booking.duration || "N/A"}</value></div>
      <div class="detail"><label>Passengers</label><value>${ticket.passengers || 1}</value></div>
      <div class="detail"><label>Status</label><value style="color:#22c55e">CONFIRMED</value></div>
    </div>
    <div class="barcode">
      <div>
        <div class="barcode-lines">
          ${Array.from({ length: 30 }, (_, i) => `<span style="height:${[48, 36, 42, 36, 48, 40, 36, 48][i % 8]}px;width:${i % 5 === 0 ? 4 : 2}px"></span>`).join("")}
        </div>
        <div class="ref" style="margin-top:8px">REF: BKA${Math.random().toString(36).substr(2, 8).toUpperCase()}</div>
      </div>
      <div class="price-badge">
        <div class="label">TOTAL FARE</div>
        <div class="amount">${formatCurrency(booking.price, booking.currency)}</div>
      </div>
    </div>
  </div>
</div>
</body>
</html>`;

interface Message {
  role: "user" | "assistant";
  content?: string;
  chat?: string;
  options?: any[];
  intent?: any;
  booked?: any;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      chat: "👋 Hi! I'm your AI ticket booking assistant. Just tell me where you want to go and when — I'll search and find the best options for you!\n\nExamples:\n• \"Book a flight from Chennai to Delhi on March 15 at 8 AM\"\n• \"Train from Mumbai to Pune tomorrow evening\"\n• \"Movie tickets for Avengers tonight at 7 PM\"",
      options: []
    }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [currentIntent, setCurrentIntent] = useState<any>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [pastBookings, setPastBookings] = useState<any[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const conversationHistory = useRef<any[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("bookai_history");
    if (saved) {
      try {
        setPastBookings(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMsg }]);
    setLoading(true);

    try {
      const result = await getBookingResponse(userMsg, conversationHistory.current);
      
      // Update history for next turn
      conversationHistory.current.push({ role: "user", parts: [{ text: userMsg }] });
      conversationHistory.current.push({ role: "model", parts: [{ text: JSON.stringify(result) }] });

      if (result.intent) setCurrentIntent(result.intent);
      
      setMessages(prev => [...prev, {
        role: "assistant",
        chat: result.chat || result.summary || "Here are the options I found:",
        options: result.options || [],
        intent: result.intent
      }]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, {
        role: "assistant",
        chat: "Sorry, I had trouble searching. Please try again.",
        options: []
      }]);
    }
    setLoading(false);
  };

  const downloadTicket = (booking: any, intentOverride?: any) => {
    const intent = intentOverride || currentIntent || {};
    const html = generateTicketHTML(intent, booking);
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ticket-${booking.name.replace(/\s+/g, "-")}-${intent.date || "booking"}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleBook = (option: any) => {
    const newBooking = {
      id: Date.now().toString(),
      option,
      intent: currentIntent,
      timestamp: new Date().toISOString()
    };

    const updatedHistory = [newBooking, ...pastBookings];
    setPastBookings(updatedHistory);
    localStorage.setItem("bookai_history", JSON.stringify(updatedHistory));

    // Automatically open official booking page
    if (option.booking_url) {
      window.open(option.booking_url, "_blank");
    }

    setMessages(prev => [...prev, {
      role: "assistant",
      chat: `✅ Excellent choice! I've saved your booking for **${option.name}** to your history. I've also opened the official booking page in a new tab for you to complete your payment.\n\nWhat would you like to do next?`,
      options: [],
      booked: option
    }]);
  };

  const clearHistory = () => {
    setPastBookings([]);
    localStorage.removeItem("bookai_history");
  };

  const deleteBooking = (id: string) => {
    const updated = pastBookings.filter(b => b.id !== id);
    setPastBookings(updated);
    localStorage.setItem("bookai_history", JSON.stringify(updated));
  };

  const availabilityColor = (a: string) => {
    if (a.includes("Available")) return "text-emerald-400";
    if (a.includes("Limited")) return "text-amber-400";
    return "text-rose-400";
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#0f0f1a] text-white font-mono selection:bg-rose-500/30">
      {/* Header */}
      <header className="sticky top-0 z-50 flex items-center gap-4 px-6 py-4 bg-white/5 backdrop-blur-xl border-b border-white/10">
        <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-rose-500 to-rose-700 shadow-lg shadow-rose-500/20">
          <Plane className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">BookAI</h1>
          <p className="text-[10px] text-white/40 uppercase tracking-[0.2em]">AI-Powered Concierge</p>
        </div>
        <nav className="hidden md:flex ml-auto gap-2">
          {[
            { icon: Plane, label: "Flights" },
            { icon: Train, label: "Trains" },
            { icon: Film, label: "Movies" },
            { icon: Music, label: "Events" }
          ].map(({ icon: Icon, label }) => (
            <span key={label} className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-[11px] text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-default">
              <Icon className="w-3 h-3" />
              {label}
            </span>
          ))}
        </nav>
        <button 
          onClick={() => setHistoryOpen(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-xs font-bold"
        >
          <Clock className="w-4 h-4 text-rose-400" />
          History
        </button>
      </header>

      {/* Booking History Sidebar */}
      <AnimatePresence>
        {historyOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setHistoryOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-[#16162a] border-l border-white/10 z-[70] shadow-2xl flex flex-col"
            >
              <div className="p-6 border-b border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-rose-400" />
                  <h2 className="font-display text-xl font-bold">Booking History</h2>
                </div>
                <button onClick={() => setHistoryOpen(false)} className="p-2 hover:bg-white/5 rounded-lg transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {pastBookings.length === 0 ? (
                  <div className="text-center py-20 text-white/20">
                    <Clock className="w-12 h-12 mx-auto mb-4 opacity-20" />
                    <p className="text-sm">No bookings yet</p>
                  </div>
                ) : (
                  pastBookings.map((booking) => (
                    <div key={booking.id} className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3 group">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="text-xs text-white/40 mb-1">
                            {new Date(booking.timestamp).toLocaleDateString()} • {new Date(booking.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                          <h3 className="font-bold text-rose-400">{booking.option.name}</h3>
                          <div className="text-xs text-white/60 mt-1">
                            {booking.intent?.from} → {booking.intent?.to}
                          </div>
                        </div>
                        <button 
                          onClick={() => deleteBooking(booking.id)}
                          className="p-2 text-white/20 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-white/5">
                        <div className="text-sm font-bold">{formatCurrency(booking.option.price, booking.option.currency)}</div>
                        <button 
                          onClick={() => downloadTicket(booking.option, booking.intent)}
                          className="text-[10px] font-bold uppercase tracking-widest text-white/40 hover:text-white flex items-center gap-1 transition-colors"
                        >
                          <Download className="w-3 h-3" />
                          Ticket
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {pastBookings.length > 0 && (
                <div className="p-6 border-t border-white/10">
                  <button 
                    onClick={clearHistory}
                    className="w-full py-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-bold uppercase tracking-widest hover:bg-rose-500 hover:text-white transition-all"
                  >
                    Clear All History
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-6 space-y-8 max-w-4xl mx-auto w-full">
        <AnimatePresence initial={false}>
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div className={`flex gap-4 max-w-[85%] ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                <div className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center ${msg.role === "user" ? "bg-rose-600" : "bg-white/10 border border-white/10"}`}>
                  {msg.role === "user" ? <div className="text-xs font-bold">ME</div> : <Bot className="w-5 h-5 text-rose-400" />}
                </div>
                
                <div className="space-y-4">
                  {(msg.content || msg.chat) && (
                    <div className={`px-5 py-3.5 rounded-2xl text-sm leading-relaxed ${
                      msg.role === "user" 
                        ? "bg-gradient-to-br from-rose-500 to-rose-600 shadow-lg shadow-rose-500/10 rounded-tr-none" 
                        : "bg-white/5 border border-white/10 rounded-tl-none"
                    }`}>
                      {msg.content || msg.chat}
                    </div>
                  )}

                  {/* Options Grid */}
                  {msg.options && msg.options.length > 0 && (
                    <div className="grid gap-4">
                      {msg.options.map((opt) => (
                        <motion.div
                          key={opt.id}
                          whileHover={{ scale: 1.01 }}
                          className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-rose-500/50 transition-all group"
                        >
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h3 className="font-bold text-lg group-hover:text-rose-400 transition-colors">{opt.name}</h3>
                              <div className="flex flex-wrap gap-2 mt-2">
                                {opt.highlights?.map((h: string) => (
                                  <span key={h} className="px-2 py-0.5 rounded-md bg-rose-500/10 border border-rose-500/20 text-[10px] text-rose-400 uppercase font-bold tracking-wider">
                                    {h}
                                  </span>
                                ))}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-2xl font-bold text-rose-500">{formatCurrency(opt.price, opt.currency)}</div>
                              <div className={`text-[10px] font-bold mt-1 uppercase tracking-wider ${availabilityColor(opt.availability)}`}>
                                ● {opt.availability}
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-5 text-xs text-white/40">
                            {opt.departure && (
                              <div>
                                <div className="uppercase tracking-widest mb-1">Depart</div>
                                <div className="text-white font-bold">{opt.departure}</div>
                              </div>
                            )}
                            {opt.arrival && (
                              <div>
                                <div className="uppercase tracking-widest mb-1">Arrive</div>
                                <div className="text-white font-bold">{opt.arrival}</div>
                              </div>
                            )}
                            {opt.duration && (
                              <div>
                                <div className="uppercase tracking-widest mb-1">Duration</div>
                                <div className="text-white font-bold">{opt.duration}</div>
                              </div>
                            )}
                            {opt.class && (
                              <div>
                                <div className="uppercase tracking-widest mb-1">Class</div>
                                <div className="text-white font-bold">{opt.class}</div>
                              </div>
                            )}
                          </div>

                          <div className="flex gap-3">
                            <button
                              onClick={() => handleBook(opt)}
                              className="flex-1 bg-rose-600 hover:bg-rose-500 text-white font-bold py-2.5 rounded-xl transition-colors text-sm"
                            >
                              Book Now
                            </button>
                            <button
                              onClick={() => downloadTicket(opt)}
                              className="px-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl transition-colors"
                              title="Preview Ticket"
                            >
                              <Download className="w-4 h-4" />
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  {/* Booking Confirmation */}
                  {msg.booked && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 space-y-4"
                    >
                      <div className="flex items-center gap-3 text-emerald-400">
                        <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
                          <ExternalLink className="w-4 h-4" />
                        </div>
                        <div className="text-sm font-bold">Booking Initiated: {msg.booked.name}</div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <button
                          onClick={() => downloadTicket(msg.booked)}
                          className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold py-3 rounded-xl transition-colors text-xs flex items-center justify-center gap-2"
                        >
                          <Download className="w-4 h-4" />
                          Download Ticket
                        </button>
                        {msg.booked.booking_url && (
                          <a
                            href={msg.booked.booking_url}
                            target="_blank"
                            rel="noreferrer"
                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl transition-colors text-xs flex items-center justify-center gap-2"
                          >
                            <ExternalLink className="w-4 h-4" />
                            Official Site
                          </a>
                        )}
                      </div>
                    </motion.div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {loading && (
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-lg bg-white/10 border border-white/10 flex items-center justify-center">
              <Bot className="w-5 h-5 text-rose-400" />
            </div>
            <div className="bg-white/5 border border-white/10 px-5 py-3.5 rounded-2xl rounded-tl-none flex items-center gap-3">
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-bounce" />
                <div className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                <div className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
              <span className="text-xs text-white/40 font-bold uppercase tracking-widest">Searching live options...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </main>

      {/* Input Bar */}
      <footer className="p-6 bg-gradient-to-t from-[#0f0f1a] to-transparent">
        <div className="max-w-4xl mx-auto relative group">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleSend()}
            placeholder="Where would you like to go?"
            className="w-full bg-white/5 border border-white/10 focus:border-rose-500/50 rounded-2xl px-6 py-4 pr-16 outline-none transition-all placeholder:text-white/20 text-sm"
          />
          <button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="absolute right-2 top-2 bottom-2 px-4 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 disabled:hover:bg-rose-600 text-white rounded-xl transition-all flex items-center justify-center"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
        <p className="text-center mt-4 text-[9px] text-white/20 uppercase tracking-[0.3em] font-bold">
          Powered by Gemini AI • Real-time Web Search Enabled
        </p>
      </footer>
    </div>
  );
}

